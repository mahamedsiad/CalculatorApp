﻿///////////////////////////////////////////////////////
// TINFO 200 A, Winter 2023
// This program creates a simple desktop calculator.
// It allows you to add and subtract numbers.
// It is simple and very user friendly.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        private decimal valueFirst = 0.0m;
        private decimal valueSecond = 0.0m;
        private decimal result = 0.0m;
        private string operators = "+";
        public Form1()
        {
            InitializeComponent();
        }

        private void ZeroBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "0";
            }
            else
            {
                txtBox.Text += "0";
            }
        }

        private void DotBtn_Click(object sender, EventArgs e)
        {
            if (!txtBox.Text.Contains("."))
            {
                txtBox.Text += ".";
            }

        }

        private void OneBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "1";
            }
            else
            {
                txtBox.Text += "1";
            }
        }

        private void TwoBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "2";
            }
            else
            {
                txtBox.Text += "2";
            }
        }

        private void ThreeBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "3";
            }
            else
            {
                txtBox.Text += "3";
            }
        }

        private void FourBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "4";
            }
            else
            {
                txtBox.Text += "4";
            }
        }

        private void FiveBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "5";
            }
            else
            {
                txtBox.Text += "5";
            }
        }

        private void SixBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "6";
            }
            else
            {
                txtBox.Text += "6";
            }
        }

        private void SevenBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "7";
            }
            else
            {
                txtBox.Text += "7";
            }
        }

        private void EightBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "8";
            }
            else
            {
                txtBox.Text += "8";
            }
        }

        private void NineBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text == "0")
            {
                txtBox.Text = "9";
            }
            else
            {
                txtBox.Text += "9";
            }
        }

        private void PlusMinusBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text.Contains("-"))
            {
                txtBox.Text = txtBox.Text.Trim('-');
            }
            else
            {
                txtBox.Text = '-' + txtBox.Text;
            }
        }

        private void MinusBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(txtBox.Text);
            txtBox.Clear();
            operators = "-";
        }

        private void PlusBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(txtBox.Text);
            txtBox.Clear();
            operators = "+";
        }

        private void DivideBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(txtBox.Text);
            txtBox.Clear();
            operators = "/";
        }

        private void MultiplyBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(txtBox.Text);
            txtBox.Clear();
            operators = "*";
        }

        private void EqualsBtn_Click(object sender, EventArgs e)
        {
            switch (operators)
            {
                case "-":
                    valueSecond = decimal.Parse(txtBox.Text);
                    result = valueFirst - valueSecond;
                    txtBox.Text = result.ToString();
                    break;
                case "+":
                    valueSecond = decimal.Parse(txtBox.Text);
                    result = valueFirst + valueSecond;
                    txtBox.Text = result.ToString();
                    break;
                case "*":
                    valueSecond = decimal.Parse(txtBox.Text);
                    result = valueFirst * valueSecond;
                    txtBox.Text = result.ToString();
                    break;
                case "/":
                    valueSecond = decimal.Parse(txtBox.Text);
                    result = valueFirst / valueSecond;
                    txtBox.Text = result.ToString();
                    break;
            }

        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            valueFirst = 0.0m;
            valueSecond = 0.0m;
            txtBox.Text = "0";
        }

        private void ClearEntryBtn_Click(object sender, EventArgs e)
        {
            txtBox.Text = "0";
        }

        private void BackspaceBtn_Click(object sender, EventArgs e)
        {
            if (txtBox.Text.Length > 1)
            {
                txtBox.Text = txtBox.Text.Substring(0, txtBox.Text.Length - 1);
                if (txtBox.Text[txtBox.Text.Length - 1] == '.')
                {
                    txtBox.Text = txtBox.Text.Substring(0, txtBox.Text.Length - 1);
                }
            }
            else
            {
                txtBox.Text = "0";

            }



        }
    }
}
